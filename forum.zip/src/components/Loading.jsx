import LoadingBar from "react-redux-loading-bar";

export default function Loading() {
    return (
        <div className="loading-bar" >
            <LoadingBar />
        </div>
    )
}