export default function NotFoundPage() {
    return (
        <section className='homepage'>
            <h1>404</h1>
            <h2>Page Not Found</h2>
        </section>
    )
}