import { Link } from "react-router-dom";
import { LOGIN_PAGE_PATH } from "../utils/RoutePath";
import { useDispatch } from "react-redux";
import useInput from "../hooks/UseInput";
import { asyncRegisterUser } from "../states/users/action";

export default function RegisterPage() {
    const dispatch = useDispatch();

    const [name, onNameChane] = useInput('');
    const [email, onEmailChange] = useInput('');
    const [password, onPasswordChange] = useInput('');

    function onRegister(event) {
        event.preventDefault();
        dispatch(asyncRegisterUser({ name, email, password }));
    }

    return (
        <div className="container">
            <div className="row">
                <div className="col-md-6 offset-md-3">
                    <h2 className="text-center text-dark mt-5">Register</h2>
                    <div className="card my-5">
                        <form className="card-body cardbody-color p-lg-5">
                            <div className="text-center">
                                <img src="src/assets/logo2.jpg" className="img-fluid profile-image-pic img-thumbnail rounded-circle my-3" width="200px" alt="profile" />
                            </div>
                            <div className="mb-3">
                                <input type="text" className="form-control" placeholder="Name" value={name} onChange={onNameChane} />
                            </div>
                            <div className="mb-3">
                                <input type="email" className="form-control" placeholder="Email" value={email} onChange={onEmailChange} />
                            </div>
                            <div className="mb-3">
                                <input type="password" className="form-control" placeholder="Password" value={password} onChange={onPasswordChange} />
                            </div>
                            <div className="text-center">
                                <button type="submit" className="btn btn-primary px-5 mb-5 w-100" onClick={onRegister}>Register</button>
                            </div>
                            <div id="emailHelp" className="form-text text-center mb-5 text-dark">
                                Already have an account? <Link to={LOGIN_PAGE_PATH} className="text-dark fw-bold"> Login here</Link>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    );
}